describe("The searches controller", function() {
    var controller = Ext.ControllerManager.get("searches");

    describe("the show action", function() {
        beforeEach(function() {
            
        });
    });


});
