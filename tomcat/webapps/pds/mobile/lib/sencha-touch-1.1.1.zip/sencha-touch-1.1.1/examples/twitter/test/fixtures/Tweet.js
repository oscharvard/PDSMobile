(function() {
    var Tweet = Ext.ModelMgr.getModel("Tweet");
    
    fixtures.Tweet = {
        
    };
})();
