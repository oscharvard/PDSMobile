describe("A Tweet", function() {
    var Tweet = Ext.ModelMgr.getModel("Tweet"),
        instance;
    
    beforeEach(function() {
        instance = new Tweet({});
    });
});
