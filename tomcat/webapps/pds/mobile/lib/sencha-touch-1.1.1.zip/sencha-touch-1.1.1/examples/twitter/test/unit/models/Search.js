describe("A Search", function() {
    var Search = Ext.ModelMgr.getModel("Search"),
        instance;
    
    beforeEach(function() {
        instance = new Search({});
    });
});
