(function() {
    var Search = Ext.ModelMgr.getModel("Search");
    
    fixtures.Search = {
        
    };
})();
