describe("The tweets controller", function() {
    var controller = Ext.ControllerManager.get("tweets");

    describe("the search action", function() {
        beforeEach(function() {
            
        });
    });


});
